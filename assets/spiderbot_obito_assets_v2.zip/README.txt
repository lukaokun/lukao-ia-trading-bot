SpiderBot Obito visual assets

Copy the two PNG files into the repository's assets/ directory:
- obito-header.png
- obito-arena.png

The dashboard HTML in PR #3 references these exact paths.
The PR adds animated CSS overlays and reduced-motion support.
Images are generated artwork, not original layered source files.
